#!/usr/bin/env node

require('grunt').tasks("test");